package com.smartexcel.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import androidx.compose.ui.window.Dialog
import kotlin.math.max

private val ExcelGreen = Color(0xFF137C4B)
private val HeaderBg = Color(0xFFEAF1ED)
private val GridLine = Color(0xFFDCE3DF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SmartExcelTheme { SpreadsheetScreen() } }
    }
}

@Composable
private fun SmartExcelTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = ExcelGreen,
            secondary = Color(0xFF2F8F65),
            surface = Color.White,
            background = Color(0xFFF4F7F5)
        ),
        content = content
    )
}

@Composable
fun SpreadsheetScreen() {
    val cells = remember { mutableStateMapOf<String, String>() }
    var selectedCell by remember { mutableStateOf("A1") }
    var formulaText by remember { mutableStateOf("") }
    var sheetName by remember { mutableStateOf("Sheet1") }
    var showSheetDialog by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Ready") }

    fun updateCell(value: String) {
        formulaText = value
        if (value.isBlank()) cells.remove(selectedCell) else cells[selectedCell] = value
        status = "Edited $selectedCell"
    }

    Column(
        Modifier.fillMaxSize().background(Color(0xFFF4F7F5))
    ) {
        // App toolbar
        Row(
            Modifier.fillMaxWidth().background(ExcelGreen).padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Smart Excel", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            Text("Workbook", color = Color.White.copy(alpha = .85f), fontSize = 13.sp)
            Spacer(Modifier.width(12.dp))
            Icon(Icons.Default.MoreVert, contentDescription = "More", tint = Color.White)
        }

        // Compact ribbon
        Row(
            Modifier.fillMaxWidth().background(Color.White).horizontalScroll(rememberScrollState()).padding(horizontal = 10.dp, vertical = 7.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            RibbonAction("Home", true)
            RibbonAction("Insert")
            RibbonAction("Data")
            RibbonAction("View")
            RibbonAction("Format")
        }

        // Formula bar
        Row(
            Modifier.fillMaxWidth().background(Color.White).padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier.width(62.dp).height(42.dp).background(HeaderBg, RoundedCornerShape(6.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text(selectedCell, fontWeight = FontWeight.Bold, color = ExcelGreen)
            }
            Spacer(Modifier.width(8.dp))
            Text("fx", color = ExcelGreen, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Spacer(Modifier.width(8.dp))
            BasicTextField(
                value = formulaText,
                onValueChange = ::updateCell,
                modifier = Modifier.weight(1f).heightIn(min = 42.dp)
                    .background(Color(0xFFF5F7F6), RoundedCornerShape(6.dp))
                    .padding(horizontal = 12.dp, vertical = 11.dp),
                singleLine = true,
                textStyle = LocalTextStyle.current.copy(fontSize = 15.sp, color = Color(0xFF202824)),
                decorationBox = { inner ->
                    if (formulaText.isEmpty()) Text("Enter value or formula", color = Color.Gray, fontSize = 14.sp)
                    inner()
                }
            )
            Spacer(Modifier.width(8.dp))
            IconButton(onClick = { updateCell(formulaText) }) {
                Icon(Icons.Default.Check, contentDescription = "Apply", tint = ExcelGreen)
            }
        }

        // Grid
        SpreadsheetGrid(
            cells = cells,
            selectedCell = selectedCell,
            onSelect = { address ->
                selectedCell = address
                formulaText = cells[address].orEmpty()
                status = address
            },
            modifier = Modifier.weight(1f).fillMaxWidth()
        )

        // Bottom worksheet bar
        Row(
            Modifier.fillMaxWidth().background(Color.White).border(BorderStroke(1.dp, GridLine)).padding(horizontal = 12.dp, vertical = 7.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("‹", color = ExcelGreen, fontSize = 25.sp)
            Spacer(Modifier.width(12.dp))
            Text(sheetName, color = ExcelGreen, fontWeight = FontWeight.Bold,
                modifier = Modifier.background(HeaderBg, RoundedCornerShape(topStart = 6.dp, topEnd = 6.dp)).clickable { showSheetDialog = true }.padding(horizontal = 15.dp, vertical = 10.dp))
            IconButton(onClick = { showSheetDialog = true }) {
                Icon(Icons.Default.Add, contentDescription = "Add sheet", tint = ExcelGreen)
            }
            Spacer(Modifier.weight(1f))
            Text(status, color = Color.Gray, fontSize = 12.sp)
        }
    }

    if (showSheetDialog) {
        var name by remember { mutableStateOf(sheetName) }
        AlertDialog(
            onDismissRequest = { showSheetDialog = false },
            title = { Text("Worksheet name") },
            text = {
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Sheet name") }, singleLine = true)
            },
            confirmButton = {
                TextButton(onClick = {
                    if (name.isNotBlank()) sheetName = name.trim()
                    showSheetDialog = false
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { showSheetDialog = false }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun RibbonAction(label: String, selected: Boolean = false) {
    Text(
        label,
        color = if (selected) ExcelGreen else Color(0xFF47534D),
        fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
        modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp)
    )
}

@Composable
private fun SpreadsheetGrid(
    cells: Map<String, String>,
    selectedCell: String,
    onSelect: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val horizontal = rememberScrollState()
    val vertical = rememberScrollState()
    Column(modifier.background(Color.White).verticalScroll(vertical).horizontalScroll(horizontal)) {
        Row {
            GridHeader("#", 48)
            repeat(26) { col -> GridHeader(columnName(col), 112) }
        }
        repeat(100) { row ->
            Row {
                GridHeader((row + 1).toString(), 48)
                repeat(26) { col ->
                    val address = "${columnName(col)}${row + 1}"
                    val selected = selectedCell == address
                    Box(
                        Modifier.width(112.dp).height(42.dp)
                            .background(if (selected) Color(0xFFE6F4EB) else Color.White)
                            .border(
                                BorderStroke(
                                    if (selected) 1.5.dp else .5.dp,
                                    if (selected) ExcelGreen else GridLine
                                )
                            )
                            .clickable { onSelect(address) }
                            .padding(horizontal = 7.dp),
                        contentAlignment = Alignment.CenterStart
                    ) {
                        Text(cells[address].orEmpty(), maxLines = 1, fontSize = 14.sp, color = Color(0xFF202824))
                    }
                }
            }
        }
    }
}

@Composable
private fun GridHeader(text: String, width: Int) {
    Box(
        Modifier.width(width.dp).height(42.dp).background(HeaderBg)
            .border(BorderStroke(.5.dp, GridLine)),
        contentAlignment = Alignment.Center
    ) {
        Text(text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF42534A))
    }
}

private fun columnName(index: Int): String {
    var n = index + 1
    var result = ""
    while (n > 0) {
        val rem = (n - 1) % 26
        result = ('A' + rem) + result
        n = (n - 1) / 26
    }
    return result
}
