# Smart Excel — Android Studio Project

A tablet-oriented Android spreadsheet UI starter built with Kotlin and Jetpack Compose.

## Open in Android Studio
1. Extract `SmartExcel_Project.zip`.
2. Open Android Studio.
3. Choose **Open** and select the extracted `SmartExcel` folder.
4. Allow Gradle sync to finish.
5. Select an emulator or connected Android tablet and press Run.

## Requirements
- Android Studio with Android Gradle Plugin 8.7.3 support
- JDK 17
- Android SDK 35

## Current prototype features
- Tablet-friendly spreadsheet screen
- 26 columns (A–Z) and 100 visible rows
- Cell selection and direct editing through the formula bar
- Basic worksheet name editing
- Horizontal and vertical scrolling

## Not implemented yet
This is the initial UI prototype, not a complete Excel replacement. XLSX import/export, formula calculation, multiple real worksheets, formatting, copy/paste, sorting/filtering, persistence and autosave are planned next.

Package: `com.smartexcel.app`
